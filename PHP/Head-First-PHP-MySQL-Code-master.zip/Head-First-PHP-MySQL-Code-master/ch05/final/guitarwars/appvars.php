<?php
  // Define application constants
  define('GW_UPLOADPATH', 'images/');
  define('GW_MAXFILESIZE', 32768);      // 32 KB
?>
