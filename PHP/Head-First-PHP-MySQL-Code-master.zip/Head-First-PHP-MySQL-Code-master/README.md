## Head-First-PHP-MySQL-Code
=========================

### Head First PHP & MySQL Code

This is the project code that accompanies [Head First PHP & MySQL, 2nd Edition](http://shop.oreilly.com/product/0636920029298.do). Code for each chapter is included and the more complex projects are broken into multiple stages.  This code currently targets PHP 5.2.6 and above, MySQL 5.0 and above.

Feng David
ccf19881030@126.com
28/7/2014

### DownLoad
- HeadFirst Labs  : [http://www.headfirstlabs.com/books/hfphp/](http://www.headfirstlabs.com/books/hfphp/)

- HeadFirst系列书籍下载地址：[华为网盘下载](http://dl.dbank.com/c0luaykzj4)




