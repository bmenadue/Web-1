<?php
  // Define database connection constants
  define('DB_HOST', 'data.mis-match.net');
  define('DB_USER', 'admin');
  define('DB_PASSWORD', 'douluveme');
  define('DB_NAME', 'mismatchdb');
?>
